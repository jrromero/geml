#!/bin/bash

java -Xmx6g -cp geml.jar:lib/*:\
repo/1\ -\ QuickUML\ 2001/bin:\
repo/2\ -\ Lexi\ v0.1.1\ alpha/bin:\
repo/3\ -\ JRefactory\ v2.6.24/bin:\
repo/3\ -\ JRefactory\ v2.6.24/lib/*:\
repo/4\ -\ Netbeans\ v1.0.x/bin:\
repo/5\ -\ JUnit\ v3.7/bin:\
repo/6\ -\ JHotDraw\ v5.1/bin:\
repo/8\ -\ MapperXML\ v1.9.7/bin:\
repo/8\ -\ MapperXML\ v1.9.7/lib/*:\
repo/10\ -\ Nutch\ v0.4/bin:\
repo/10\ -\ Nutch\ v0.4/lib/*:\
repo/11\ -\ PMD\ v1.8/bin:\
repo/11\ -\ PMD\ v1.8/lib/*:\
repo/DesignPatternExample/bin: \
uco.kdis.dpd.gui.DPDTool
