package com.jmonkey.office.lexi.support;

public abstract class ActionManager {
}
