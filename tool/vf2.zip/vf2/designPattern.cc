#include <argraph.h>
#include <match.h>
#include <fstream>
#include <iostream>
#include <argloader.h>
#include <allocpool.h>
#include "vf2_sub_state.h"
#include "vf2_state.h"
#include "vf2_mono_state.h"
#include <stdlib.h>
#include <cstring>

using namespace std;

// Clase y metodos necesarios para indicar que ni los nodos ni las aristas tienen atributos

class Empty {};

istream& operator>>(istream& in, Empty &) 
{
	return in;
}

ostream& operator<<(ostream& out, Empty &) 
{
	return out;
}

// Para poder ordenar

int compare( const void* a, const void* b)
{
	int int_a = * ( (int*) a );
	int int_b = * ( (int*) b );

	if ( int_a == int_b ) return 0;
	else if ( int_a < int_b ) return -1;
	else return 1;
}

// Procesamiento que se realiza cada vez que se encuentra una coincidencia

bool my_visitor(int n, node_id ni1[], node_id ni2[], void *usr_data)
{
	FILE *f = (FILE *)usr_data;
	int i;


	// Save the nodes id of the "big" graph (the source code project)
	for(i=0; i<n; i++) {
		// se suma 1 para que coincida con los indices de las clases en el formato de sgiso
		fprintf(f, "%hd,%hd ", ni1[i], ni2[i]);
	}
	fprintf(f, "\n");

	// Metodo en el que solo me interesa las clases encontradas
	// pero no su ubicacion dentro del subgrafo

	/*
	int nodes [n];

    for(i=0; i<n; i++)
        //nodes[i] = ni2[i];

    qsort(nodes, n, sizeof(int), compare ) ;

    for(i=0; i<n; i++)
        fprintf(f, "%d ", nodes[i]);

    fprintf(f, "\n");
	 */

	return false;
}


int main(int argc, char *argv[])
{
    if(argc==4) {

	    // Load graphs
	    NullAllocator<Empty> allocator;

	    ifstream pattern(argv[1]);
	    ifstream project(argv[2]);

	    StreamARGLoader<Empty,Empty> loaderPattern(&allocator, &allocator, pattern);
	    StreamARGLoader<Empty,Empty> loaderProject(&allocator, &allocator, project);

	    ARGraph<Empty,Empty> graphPattern(&loaderPattern);
	    ARGraph<Empty,Empty> graphProject(&loaderProject);

	    // The algorithm
	    VF2MonoState s0(&graphPattern, &graphProject);
	    //VF2SubState s0(&graphPattern, &graphProject);
	    //VF2State s0(&graphPattern, &graphProject);

	    // The report
	    FILE * f=fopen(argv[3], "w");

	    // Launch algorithm
	    match(&s0, my_visitor, f);
	    fclose(f);
    }
    else
        cout << "Error de argumentos" << endl;

	return 0;
}
